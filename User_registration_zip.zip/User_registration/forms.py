from django import forms
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.forms import UsernameField, AuthenticationForm,\
    PasswordResetForm, PasswordChangeForm, SetPasswordForm
from django.contrib.auth import password_validation


class Loginform(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={'placeholder':'Username','autofocus':True,'class':'text-success font-weight-bold mt-2 form-control'}),
                             error_messages={"required":"Please Enter Username"})
    password = forms.CharField(
        label= _("Password"),
        strip = False,
        widget=forms.PasswordInput(attrs={'placeholder':'Password','autocomplete':'curent-password','class':'login_pass mt-2 font-weight-bold text-danger form-control'}),
        error_messages={"required":"Please Enter Password"}
    )
    
    
class Passwordresetform(PasswordResetForm):
    email = forms.EmailField(
    label=_("Email ID"),
    max_length=100,
    widget=forms.EmailInput(attrs={'placeholder':'Email Address','autofocus':True,'autocomplete': 'email','class':'form-control mt-2 font-weight-bold text-success'}),
    error_messages={"required":"Please Enter Email"}
    )

class PasswordchangeForm(PasswordChangeForm,SetPasswordForm):
    error_messages = {
    'password_mismatch': _('The two password fields didn’t match.'),
    }
    new_password1 = forms.CharField(
        label=_("New password"),
        widget=forms.PasswordInput(attrs={'placeholder':'Password','autocomplete': 'new-password','class':'form-control text-success text-weight-bold my-2',}),
        strip=False,
        help_text=password_validation.password_validators_help_text_html(),
    )
    new_password2 = forms.CharField(
        label=_("New password confirmation"),
        strip=False,
        widget=forms.PasswordInput(attrs={'placeholder':'Confirm Password','autocomplete': 'new-password','class':'form-control text-success text-weight-bold my-2',}),
    )
    
    
    error_messages = {
    **SetPasswordForm.error_messages,
    'password_incorrect': _("Your old password was entered incorrectly. Please enter it again."),
    }
    old_password = forms.CharField(
        label=_("Old password"),
        strip=False,
        widget=forms.PasswordInput(attrs={'placeholder':'Old Password','autocomplete': 'current-password','class':'form-control my-2 text-danger text-weight-bold','autofocus':True}),
    )
    
    field_order = ['old_password', 'new_password1', 'new_password2']
    

class SetpasswordForm(SetPasswordForm):
    error_messages = {
        'password_mismatch': _('The two password fields didn’t match.'),
    }
    new_password1 = forms.CharField(
        label=_("New password"),
        widget=forms.PasswordInput(attrs={'placeholder':'Password','autocomplete': 'new-password','class':'form-control text-success text-weight-bold my-2'}),
        strip=False,
        help_text=password_validation.password_validators_help_text_html(),
    )
    new_password2 = forms.CharField(
        label=_("New password confirmation"),
        strip=False,
        widget=forms.PasswordInput(attrs={'placeholder':'Confirm Password','autocomplete': 'new-password','class':'form-control text-success text-weight-bold my-2'}),
    )
